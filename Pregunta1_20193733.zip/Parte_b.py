import math
import random
import time

RADIO_DE_ZONA = 500
NUMERO_TOTAL_PERSONAS = 500000
RADIO_MUESTREO = 25

def generate_random_people():
    all_coordinates = []

    for i in range(NUMERO_TOTAL_PERSONAS):
        theta = random.uniform(0.0, 2 * math.pi)
        r = RADIO_DE_ZONA * math.sqrt(random.uniform(0.0, 1.0))
        new_coordinate = []
        new_coordinate.append(r * math.cos(theta))
        new_coordinate.append(r * math.sin(theta))
        all_coordinates.append(new_coordinate)

    return all_coordinates

"""
La funcion find_people debe retornar la cantidad de personas que se encuentran dentro del radio RADIO_MUESTREO del 
operario y que por lo tanto se le haran las pruebas rapidas.
Entradas:
operator_coordinate: La coordenada actual del operario. Es una lista de 2 elementos. Ejemplo: [-475, 0]
people_coordinates: Las coordenadas de todas las personas en la zona de 500m generada de manera aleatoria. Es una lista
                    de listas.
Salida:
people_counter: La cantidad de personas que se encuentran dentro del radio de muestreo.
"""
def find_people(operator_coordinate, people_coordinates):
    people_counter = 0

    # Iteramos por todas las personas, calculando su distancia euclidiana 
    # y verificamos que es menor o igual a RADIO_MUESTREO
    for coordinate in people_coordinates:
        distancia = ((coordinate[0]-operator_coordinate[0])**2 + (coordinate[1]-operator_coordinate[1])**2)**0.5
        if distancia <= RADIO_MUESTREO:
            people_counter += 1
    return people_counter


def main():
    people_coordinates = generate_random_people()
    start = time.time()
    total_people_tested = 0

    """
    Escriba su codigo aqui. Debe hacer uso de la funcion find_people
    """
    operator_coordinate = [-475, 0]
    pos_final = [475, 0]
    while operator_coordinate != pos_final:
        total_people_tested += find_people(operator_coordinate, people_coordinates)
        operator_coordinate[0] += 25
    print("Cantidad de personas testeadas: ", total_people_tested)
    print("Tiempo de ejecucion en serie: ", time.time() - start, "segundos")
    print("############ FIN ################")

if __name__ == '__main__':
    import cProfile
    cProfile.run('main()')
    