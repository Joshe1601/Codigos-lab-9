import socket
import time

def conectarAServidor():
    HOST = '64.225.62.28'
    PORT = 5000

            
    with socket.socket (socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect ((HOST, PORT))    
        print("Conectado a 64.225.62.28")

if __name__ == '__main__':
    conectarAServidor()
    