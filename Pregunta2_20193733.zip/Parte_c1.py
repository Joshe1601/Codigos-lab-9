import socket
import time

def conectarAServidor():
    HOST = '64.225.62.28'
    PORT = 5000

            
    with socket.socket (socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect ((HOST, PORT))    
        print("Conectado a 64.225.62.28")
        s.sendall(("GET").encode())
        respuesta = s.recv(1024)
        print("Respuesta recibida: ")
        print(respuesta)

if __name__ == '__main__':
    conectarAServidor()