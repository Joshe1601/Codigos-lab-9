import socket
import time

def conectarAServidor():
    HOST = '157.245.83.163'
    PORT = 5000

            
    with socket.socket (socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect ((HOST, PORT))    
        print("Conectado a 157.245.83.163")

if __name__ == '__main__':
    conectarAServidor()